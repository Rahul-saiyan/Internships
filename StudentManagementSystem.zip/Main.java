import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentManager manager = new StudentManager();
        while (true) {
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Search Student by ID");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = Integer.parseInt(sc.nextLine());

            if (choice == 1) {
                System.out.print("Enter ID: ");
                int id = Integer.parseInt(sc.nextLine());
                System.out.print("Enter Name: ");
                String name = sc.nextLine();
                System.out.print("Enter Age: ");
                int age = Integer.parseInt(sc.nextLine());
                System.out.print("Enter Course: ");
                String course = sc.nextLine();
                manager.addStudent(new Student(id, name, age, course));
            } else if (choice == 2) {
                manager.displayAll();
            } else if (choice == 3) {
                System.out.print("Enter ID: ");
                int id = Integer.parseInt(sc.nextLine());
                Student s = manager.findStudent(id);
                if (s != null) System.out.println(s);
                else System.out.println("Student not found");
            } else if (choice == 4) {
                System.out.print("Enter ID to update: ");
                int id = Integer.parseInt(sc.nextLine());
                System.out.print("Enter New Name: ");
                String name = sc.nextLine();
                System.out.print("Enter New Age: ");
                int age = Integer.parseInt(sc.nextLine());
                System.out.print("Enter New Course: ");
                String course = sc.nextLine();
                manager.updateStudent(id, name, age, course);
            } else if (choice == 5) {
                System.out.print("Enter ID to delete: ");
                int id = Integer.parseInt(sc.nextLine());
                manager.deleteStudent(id);
            } else if (choice == 6) {
                break;
            } else {
                System.out.println("Invalid choice");
            }
        }
    }
}
